class Weapon {
  constructor(hp,damage,actionPoint){
    this.hp=hp;
    this.damage=damage;
    this.actionPoint=actionPoint;
  }
}


var windu = new Weapon(125,34,3);
var yoda = new Weapon(135,27,3);
var darkvador = new Weapon(125,35,3);
var obiwan = new Weapon(128,33,3);
